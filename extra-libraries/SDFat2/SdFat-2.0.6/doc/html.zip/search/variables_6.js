var searchData=
[
  ['failbit_972',['failbit',['../classios__base.html#a36157154001bcce17827db6786e35efd',1,'ios_base']]],
  ['fat16_973',['fat16',['../unioncache__t.html#a8f3a4e9392a7d8ace954fc44c57df887',1,'cache_t']]],
  ['fat32_974',['fat32',['../unioncache__t.html#a57e16421bf460d1ba6cb9ce9a23a4a83',1,'cache_t']]],
  ['fat_5ftype_5fexfat_975',['FAT_TYPE_EXFAT',['../_ex_fat_partition_8h.html#ad74089b317bc77bd1e8cbb56fef8046a',1,'ExFatPartition.h']]],
  ['fat_5ftype_5ffat12_976',['FAT_TYPE_FAT12',['../_fat_partition_8h.html#a2914ab2ce1d4cff984ad93b922e99d50',1,'FatPartition.h']]],
  ['fat_5ftype_5ffat16_977',['FAT_TYPE_FAT16',['../_fat_partition_8h.html#a586e7b4151f14bd56b78a836855c0f55',1,'FatPartition.h']]],
  ['fat_5ftype_5ffat32_978',['FAT_TYPE_FAT32',['../_fat_partition_8h.html#a63da6e74b3bce481580263cebb591d5e',1,'FatPartition.h']]],
  ['flags_979',['flags',['../structfname__t.html#a39c69edff13165c6e03b308104e7286d',1,'fname_t']]],
  ['fname_5fflag_5flc_5fbase_980',['FNAME_FLAG_LC_BASE',['../_fat_file_8h.html#a79e43960e1b4eecf274f5faea9c3168c',1,'FatFile.h']]],
  ['fname_5fflag_5flc_5fext_981',['FNAME_FLAG_LC_EXT',['../_fat_file_8h.html#a135b7572768b09661aa38afaceec7296',1,'FatFile.h']]],
  ['fname_5fflag_5flost_5fchars_982',['FNAME_FLAG_LOST_CHARS',['../_fat_file_8h.html#acd45286b7dfc5ba68be18c8c3a9d298d',1,'FatFile.h']]],
  ['fname_5fflag_5fmixed_5fcase_983',['FNAME_FLAG_MIXED_CASE',['../_fat_file_8h.html#a63994c21f3b723a55247f063a1b01c9c',1,'FatFile.h']]],
  ['fname_5fflag_5fneed_5flfn_984',['FNAME_FLAG_NEED_LFN',['../_fat_file_8h.html#a1a041207a19d2fd9a1e2739343ccb29b',1,'FatFile.h']]]
];
